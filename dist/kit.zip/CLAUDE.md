# McGill Email to BOM — Kit Instructions

Read an inbound customer RFQ email and produce a deterministic CaseState plus a
draft bill of materials, with every missing, ambiguous or unsafe item raised as an
explicit open item. Drafts only — a human reviews and commits in the ERP.

## Mission

This kit turns one inbound RFQ email into a complete, structured picture of the
case: every field with a status and the evidence behind it, every missing or
unsafe item as a machine-readable open item, the request classified, and a routing
recommendation. It exists so an inside-sales rep — or a conversational layer
running the customer dialogue — never has to guess what the customer asked for and
never re-asks something already answered. The deterministic engine doing the work
is vendored verbatim under `vendor/`; the kit wraps it, it does not reimplement it.
The final deliverable is `_report/case_state.json`, the integration contract, with
`_report/bom_draft.md` as the readable companion.

## How to run

1. Read `recipes/mcgill-email-to-bom.yaml` — it is the execution contract. Execute its
   phases **in order** — `prepare` → `screen_input` → `extract_case` →
   `generate_report`; each phase's `goal`, `constraints`, `input`, and `output`
   are binding. `screen_input` runs `scripts/filter_gate.py` BEFORE the engine
   and decides, on exit code alone, whether the run continues (`0`), stops
   because there is nothing to quote (`3` — not an error), or failed in the
   gate itself (`1`).
2. Stay in the current working directory. All runtime output goes under
   `_report/` — never scatter files elsewhere.
3. Track progress in `_report/state.json` so an interrupted run can resume.
4. Deliverables are produced by the kit's scripts (`scripts/run_engine.py`,
   `generate_report.py`) — if a script fails, debug and fix it; do NOT create the
   artifact by hand.
5. **Write the run's arguments down once.** The prepare phase records an
   `invocation` object in `_report/state.json`; phases 1 and 2 read it
   (`--from-state`) rather than having you re-type the flags. Re-typing them is how
   a run ends up with two self-consistent artifacts that are both wrong about what
   the customer asked for.

## Arguments

`$ARGUMENTS` must contain the **path to one RFQ email** (`.eml` or `.txt`).
Optional: `--component-ids A B ...` for Component IDs an operator has already
confirmed, and `--coc` when the customer requires a Certificate of Conformance.
`--config-dir` selects an alternate rules/catalog directory. `--no-filter`
forces the input filter (`screen_input`) to pass this message through to the
engine regardless of its own decision — the documented escape hatch for a
false positive; it is never an engine flag and never reaches `run_engine.py`'s
argv.

If no RFQ path is given, print usage and STOP. If the path does not exist, print
the path you tried and STOP — never guess at another file and never invent email
content.

## What this kit must never do

These are not style preferences. The engine is built so that being silently wrong
is structurally impossible, and the surrounding narration has to hold the same
line:

- **Never answer, drop, reword or re-prioritize an open item.** Report them
  faithfully, highest priority first. They are the whole point of the output.
- **Never invent a part number, price, lead time or stock position.** The engine
  produces none of these. Pricing and stock questions are acknowledged and routed
  to a human.
- **Never present the output as a quote, a confirmed BOM, or an order.** It is a
  draft. A human commits it in the ERP.
- **Never treat exit code 2 as a failure.** It means "a draft was produced and it
  has open items" — the normal outcome for essentially every real RFQ. Only the
  wrapper scripts' own non-zero exits are failures.
- **Never report a `reading` or `assumed` field as confirmed.** `reading` means the
  engine saw a value and deliberately refused to commit to it (ambiguous units).
  Say it needs confirming.
- **Never edit `vendor/`** to change an outcome. It is a stamped verbatim copy; see
  `vendor/PROVENANCE.md` before touching it.
- **Never bypass a reconciliation failure.** If `generate_report.py` refuses because
  the draft would not describe the same case as `case_state.json`, re-run the extract
  phase. Do NOT pass `--no-reconcile` to get past it and do NOT write the draft by
  hand — the refusal is the safety net doing its job.
- **Never treat a missing artifact as equivalent to a stale one.** The scripts delete
  a previous run's artifacts before doing anything that can fail, on purpose: no
  artifact is an honest error, a leftover one is a silent wrong answer.
- **Never decide by hand whether a message is a request.** `screen_input`
  (`scripts/filter_gate.py`) makes that decision deterministically, before the
  engine runs. Your job is to run it and branch on its exit code — never judge
  "does this look like an RFQ" yourself and skip or force a phase on that
  judgement.
- **Never treat the gate's `3` as a failure.** It means the message was
  filtered — nothing to quote, the normal outcome for a bounce, an
  auto-reply, bulk mail, an invoice, a bare acknowledgement or internal
  chatter. Only the gate's own non-zero-but-not-3 exit (`1`) is a failure.

## Deliverables

| Path | Role |
|---|---|
| `_report/case_state.json` | **The email attachment.** The machine contract: fields with statuses and evidence, open items with codes/priorities/routes, request class, routing, knowledge provenance. Conforms to `schemas/case_state.schema.json`. |
| `_report/bom_draft.md` | Readable draft: BOM table, harness-held checkpoints, operator questions, open items. A **lossy** view of the CaseState — cite the JSON as authoritative. |
| `_report/state.json` | The run's `invocation` record (written by prepare, read by both later phases) plus the extract result. Also carries the `filter` record written by `screen_input` (`filtered`, `code`, `route`, `evidence`, `override`, `reason`, `input`) — a filtered run's only record, since it produces no other artifact. Not a deliverable. |

## Reference material

- `schemas/case_state.schema.json` — the CaseState contract: the full open-item
  code vocabulary, the request classes, and the field status/kind/route enums.
  Consult it whenever you need to know what a code means or what values are legal.
- `schemas/filter_decision.schema.json` — the `filter` record's contract: the
  closed `code`/`route`/`reason` vocabulary `screen_input` may emit. Consult it
  to know what a filtered message's code or route means.
- `reference/filter_signals.json` — the input filter's signal vocabulary
  (category detectors, cue phrases, thresholds) that `filter_gate.py` reads.
  Declared once here, never re-expressed in the gate's own code.
- `vendor/` — the vendored engine and its `config/` (all domain vocabulary lives in
  `config/rules.json`). Read-only. `vendor/PROVENANCE.md` records the exact source
  commit and how to refresh it.
- `vendor/config/citations.json` — maps each rule id to the McGill work instruction
  or test-report item it came from, so any behaviour can be traced to its source.
